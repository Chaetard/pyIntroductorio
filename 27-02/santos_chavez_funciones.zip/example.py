def suma():
    a = 10
    b = 23
    
    return a + b

print(suma())