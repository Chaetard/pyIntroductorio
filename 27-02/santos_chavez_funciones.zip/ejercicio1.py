def suma():
    var1 = int(input("Ingrese el primer valor: "))
    var2 = int(input("Ingrese el Segundo valor: "))
    return(var1 + var2)

print("el valor es de: ", suma())