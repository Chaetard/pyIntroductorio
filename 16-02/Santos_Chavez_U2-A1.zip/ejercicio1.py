a = 2
b = 9
c = 0 
if a != 0:
        c = -b / a
        print("la solucion es: ", c)
elif b != 0:
        print("la solucion es imposible")        
else:
        print("solucion no determinada")


